package com.bmessenger.bmessenger;

import java.util.ArrayList;

/**
 * Created by uli on 11/14/2016.
 */

public class Channel {
    ArrayList<Message> messageList;
    ArrayList<User> userList;
    String id;
    String name;


}
