package com.bmessenger.bmessenger;

/**
 * Created by uli on 11/14/2016.
 */

public class Message {

    String mMessage;

    public Message(String message) {
        mMessage = message;
    }

    public String getMessage() {
        return mMessage;
    }

}
